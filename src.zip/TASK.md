**Web Team Onboarding Task: Match Results Module**

**Goal:** Build a small but production-quality Angular feature so we can see how you structure code, manage state, and follow our team standards. Treat this like real work, not a throwaway exercise. The quality of the code matters more than the number of features.

**Time budget:** 5 days. Suggested pacing is at the bottom. Submit by the end of the week.

**Stack:** Angular 21 (standalone), TypeScript, signals. No backend to set up, you consume a free public API.

**Technology Stack:** Angular 21 (standalone) with TypeScript and signals. You will consume a free public API, so no backend setup is required.

**Prioritize the Developer Guide:** Before starting, review the provided \`DEVELOPER\_GUIDE.md\`. This document is the definitive source for our Angular standards, covering everything from component structure and signals to naming conventions, styling, and commit standards.

The requirements listed below are derived directly from this guide. We expect you to follow our team's established standards rather than personal habits. A significant portion of this evaluation focuses on your ability to interpret and consistently apply these internal benchmarks.

**What you are building**

A standalone **Match Results** feature: a small app that shows recent football match results for a league, lets the user search and filter them, and opens a detailed view for a single match. This mirrors the kind of data-driven screens we build in our consoles.

**Screens:**

1\. **Results list** (*/results*)  
   \- A league selector (at least 3 leagues, your choice from the API below).  
   \- A list of recent matches for the selected league, each showing: home team, away team, final score, and date.  
   \- A *search box* that filters the visible matches by team name (live, as you type).  
   \- *KPI tiles* at the top, computed from the currently shown matches: total matches, total goals, average goals per match. These must update when the league or search changes.  
   \- Proper *loading*, *empty* ("no matches found"), and *error* states. Not just a blank screen.

2\. **Match detail** (*/results/:i*\`)  
   \- Opened by clicking a match in the list.  
   \- Shows the fuller detail the API returns for that match (teams, score, date, league, venue/season if available, thumbnail if present).  
   \- A back link to the list.

**Data source:**

Use *TheSportsDB* free API (test key \`3\`, no signup, no key to store):

\- Recent events for a league: *https://www.thesportsdb.com/api/v1/json/3/eventspastleague.php?id=4328*  
  (4328 \= English Premier League. Other ids: 4335 La Liga, 4331 Bundesliga, 4332 Serie A, 4334 Ligue 1.)  
\- Single event by id: *https://www.thesportsdb.com/api/v1/json/3/lookupevent.php?id=441613*

If the API is ever down during your work, fall back to a local JSON file in *assets/* shaped like the API response, and note that in your README. Do not let an external outage block you.

**Hard requirements (these are how we work, follow them exactly)**

These all come straight from the Developer Guide and are non-negotiable because they are our actual house style. Getting these right is most of the evaluation. When in doubt, the guide wins.

\- *Standalone components only.* No *NgModule*.  
\- *ChangeDetectionStrategy.OnPush* on every component.  
\- *Signals for state*. Use *signal*, *computed*, and *effect*  where appropriate. The KPI tiles must be *computed* off the source signals, not manually recalculated.  
\- *New control flow syntax*: \`@if\`, \`@for\`, \`@switch\`. No \`\*ngIf\` / \`\*ngFor\`.  
\- \`*inject()*\` for dependency injection, not constructor params.  
\- *HTTP in a dedicated service*, not in the component. Type the responses with interfaces (no \`any\`).  
\- *Routing* with lazy-loaded standalone routes.  
\- *Strict typing*. \`Strict: true\` stays on. No \`any\`, no non-null \`\!\` to silence the compiler.  
\- *Lint must be clean*. Run \`ng lint\` before you submit. A red lint is an automatic deduction.  
\- *Conventional Commits* (\`feat:\`, \`fix:\`, \`refactor:\`, \`chore:\` ...). Commit in small logical steps, not one giant "final" commit. We read your git history.  
\- *No secrets committed.* There is none needed for this task; if you add any config, keep it out of git.

**Quality expectations:**

\- Sensible component breakdown (a list component, a card/row, a KPI tile, a detail page). Do not put everything in one file.  
\- Reusable presentational components take inputs and emit outputs; they do not fetch data themselves.  
\- Handle the unhappy paths: slow network (loading), no results (empty), failed request (error with a retry).  
\- Reasonable, responsive styling. It does not need to be beautiful, but it should be clean and not broken on a narrow window.  
\- A short *README.md*: how to run it, any decisions or trade-offs you made, and anything you would improve with more time.

**Stretch goals (optional, only after the core is solid):**

These are not required to pass. They help us see depth.

\- Debounce the search input.  
\- Persist the selected league in the URL (query param) so a refresh keeps it.  
\- A simple unit test for the KPI computation or the service.  
\- A "goals per match" sort toggle.

**How to submit:**

1\. A fresh Angular project (\`ng new match-results \--standalone \--style=scss\`). Push it to a Git repo you own (GitHub) and share the link, or zip it without \`node\_modules\` and send it.  
2\. Make sure \`npm install && ng serve\` runs cleanly from a fresh clone.  
3\. Include your \`README.md\`.  
4\. Have your commit history reflect how you actually worked.

**Suggested pacing:**

\- **Day 1**: Scaffold the project, set up routing and the typed HTTP service, get raw matches rendering for one league.  
\- **Day 2**: Component breakdown (list, card, KPI tile), league selector, loading/empty/error states.  
\- **Day 3**: Search/filter with computed KPIs, the detail route and page.  
\- **Day 4**: Polish styling, responsiveness, README, lint pass, commit cleanup.  
\- **Day 5**: Buffer, any stretch goals, final self-review before submitting.

If you get stuck, ask early. Knowing when and how to ask is part of the job too.

